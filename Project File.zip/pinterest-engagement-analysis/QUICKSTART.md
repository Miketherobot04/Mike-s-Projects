# Pinterest Engagement Analysis - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Clone the Repository
```bash
git clone https://github.com/[your-username]/pinterest-engagement-analysis.git
cd pinterest-engagement-analysis
```

### Step 2: Set Up Python Environment (Optional but Recommended)
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Generate the Data
```bash
cd src
python generate_data.py
cd ..
```

**Expected Output:**
```
Generating Pinterest engagement dataset...
Creating users data...
✓ Generated 5000 users
Creating pins data...
✓ Generated 10000 pins
Creating interactions data...
✓ Generated 50000 interactions

Files saved to data/raw/
```

### Step 5: Launch Jupyter Notebook
```bash
jupyter notebook
```

### Step 6: Open and Run Notebooks

1. **Start with:** `notebooks/01_data_exploration.ipynb`
   - Click "Cell" → "Run All"
   - Explore user demographics, pin distribution, and interaction patterns
   - Visualizations will be saved to `dashboards/` folder

2. **Continue with:** `notebooks/02_engagement_analysis.ipynb`
   - Analyzes engagement metrics
   - Performs user segmentation
   - Generates actionable insights

---

## 📊 What You'll See

### In Notebook 1 (Data Exploration):
- User demographics breakdown
- Pin content analysis by category
- Interaction patterns by time and device
- Platform health metrics

### In Notebook 2 (Engagement Analysis):
- Pin performance rankings
- Category and content type comparisons
- RFM user segmentation
- K-Means clustering results
- Business recommendations

---

## 🎯 Quick SQL Analysis

If you prefer SQL, you can also analyze the data using SQLite:

```bash
# Install SQLite (if not already installed)
# Windows: Download from sqlite.org
# Mac: brew install sqlite
# Linux: sudo apt-get install sqlite3

# Create database and import data
sqlite3 pinterest_analysis.db

# In SQLite:
.mode csv
.import data/raw/users.csv users
.import data/raw/pins.csv pins
.import data/raw/interactions.csv interactions

# Run queries from the SQL file
.read sql/analysis_queries.sql
```

---

## 📁 Key Files to Review

1. **README.md** - Full project documentation
2. **notebooks/01_data_exploration.ipynb** - Visual data exploration
3. **notebooks/02_engagement_analysis.ipynb** - Advanced analytics
4. **sql/analysis_queries.sql** - SQL analysis examples
5. **dashboards/** - Saved visualizations

---

## 🐛 Troubleshooting

### Issue: "Module not found" error
**Solution:** 
```bash
pip install --upgrade -r requirements.txt
```

### Issue: Data files not found
**Solution:**
```bash
cd src
python generate_data.py
```

### Issue: Jupyter won't start
**Solution:**
```bash
pip install --upgrade jupyter notebook
jupyter notebook --version  # Verify installation
```

### Issue: Visualizations not displaying
**Solution:** In Jupyter notebook, run:
```python
%matplotlib inline
import matplotlib.pyplot as plt
plt.rcParams['figure.dpi'] = 100
```

---

## 💡 Tips for Best Results

1. **Run cells in order** - Notebooks are designed to be run sequentially
2. **Check dashboards folder** - All visualizations are auto-saved as PNG files
3. **Explore the SQL queries** - Great examples for your own analysis
4. **Customize the analysis** - Change parameters in the data generation script
5. **Review processed data** - Check `/data/processed/` for cleaned datasets

---

## 📈 Next Steps

After completing the quick start:

1. **Customize the data** - Edit `src/generate_data.py` to change dataset size or characteristics
2. **Add your own analysis** - Create new notebooks for specific questions
3. **Build a dashboard** - Use the processed data to create Power BI visualizations
4. **Share your insights** - Document findings in the `reports/` folder

---

## ❓ Need Help?

- **Documentation:** See README.md for full details
- **Code comments:** All notebooks have detailed explanations
- **SQL examples:** Check sql/analysis_queries.sql

---

## ✅ Success Checklist

- [ ] Repository cloned
- [ ] Dependencies installed
- [ ] Data generated successfully
- [ ] Notebook 1 completed
- [ ] Notebook 2 completed
- [ ] Visualizations reviewed
- [ ] SQL queries explored
- [ ] Ready to showcase!

---

**You're all set! Happy analyzing! 🎉**
