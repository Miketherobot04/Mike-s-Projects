"""
Pinterest User Engagement Data Generator
Generates realistic simulated data for analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

# Configuration
NUM_USERS = 5000
NUM_PINS = 10000
NUM_INTERACTIONS = 50000
START_DATE = datetime(2024, 1, 1)
END_DATE = datetime(2024, 12, 31)

print("Generating Pinterest engagement dataset...")

# 1. Generate Users Data
print("Creating users data...")

user_ids = [f"USER_{i:06d}" for i in range(1, NUM_USERS + 1)]
countries = ['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 
             'France', 'Brazil', 'India', 'Japan', 'Mexico']
age_groups = ['18-24', '25-34', '35-44', '45-54', '55+']
user_types = ['Power User', 'Regular User', 'Casual User']

users_data = {
    'user_id': user_ids,
    'country': np.random.choice(countries, NUM_USERS, p=[0.4, 0.1, 0.1, 0.05, 0.05, 
                                                          0.05, 0.08, 0.07, 0.05, 0.05]),
    'age_group': np.random.choice(age_groups, NUM_USERS, p=[0.25, 0.35, 0.20, 0.12, 0.08]),
    'gender': np.random.choice(['Female', 'Male', 'Other'], NUM_USERS, p=[0.65, 0.33, 0.02]),
    'account_age_days': np.random.randint(30, 1800, NUM_USERS),
    'user_type': np.random.choice(user_types, NUM_USERS, p=[0.15, 0.45, 0.40])
}

users_df = pd.DataFrame(users_data)
users_df['signup_date'] = START_DATE - pd.to_timedelta(users_df['account_age_days'], unit='d')

print(f"✓ Generated {len(users_df)} users")

# 2. Generate Pins Data
print("Creating pins data...")

pin_ids = [f"PIN_{i:07d}" for i in range(1, NUM_PINS + 1)]
categories = ['Home Decor', 'Fashion', 'Food & Drink', 'DIY & Crafts', 'Beauty', 
              'Travel', 'Fitness', 'Art', 'Wedding', 'Gardening', 'Technology', 'Quotes']
content_types = ['Photo', 'Video', 'Carousel', 'Idea Pin']

# Some creators are more prolific
creator_pool = np.random.choice(user_ids, size=NUM_PINS, 
                                p=np.random.dirichlet(np.ones(NUM_USERS)*0.1))

pins_data = {
    'pin_id': pin_ids,
    'creator_id': creator_pool,
    'category': np.random.choice(categories, NUM_PINS, 
                                p=[0.15, 0.18, 0.12, 0.10, 0.11, 0.08, 0.06, 0.05, 0.04, 0.04, 0.04, 0.03]),
    'content_type': np.random.choice(content_types, NUM_PINS, p=[0.60, 0.20, 0.10, 0.10]),
    'has_description': np.random.choice([True, False], NUM_PINS, p=[0.75, 0.25]),
    'has_link': np.random.choice([True, False], NUM_PINS, p=[0.40, 0.60]),
    'is_promoted': np.random.choice([True, False], NUM_PINS, p=[0.05, 0.95])
}

pins_df = pd.DataFrame(pins_data)

# Generate creation dates
date_range = (END_DATE - START_DATE).days
pins_df['created_date'] = [START_DATE + timedelta(days=random.randint(0, date_range)) 
                           for _ in range(NUM_PINS)]

# Add quality score (affects engagement)
pins_df['quality_score'] = np.random.beta(5, 2, NUM_PINS)  # Skewed towards higher quality

print(f"✓ Generated {len(pins_df)} pins")

# 3. Generate Interactions Data
print("Creating interactions data...")

interaction_types = ['impression', 'click', 'save', 'repin', 'close_up']

interactions_list = []

for _ in range(NUM_INTERACTIONS):
    user_id = random.choice(user_ids)
    pin_id = random.choice(pin_ids)
    
    # Get pin quality to influence engagement
    pin_quality = pins_df[pins_df['pin_id'] == pin_id]['quality_score'].values[0]
    
    # Interaction date should be after pin creation
    pin_created = pins_df[pins_df['pin_id'] == pin_id]['created_date'].iloc[0]
    pin_created = pd.to_datetime(pin_created)
    days_after_creation = random.randint(0, min(90, (END_DATE - pin_created).days))
    interaction_date = pin_created + timedelta(days=days_after_creation)
    
    # Hour of day affects engagement (peak times)
    hour_weights = [0.02, 0.01, 0.01, 0.01, 0.01, 0.02, 0.03, 0.05, 
                   0.06, 0.05, 0.04, 0.05, 0.06, 0.05, 0.04, 0.04,
                   0.06, 0.07, 0.08, 0.09, 0.08, 0.06, 0.04, 0.03]
    hour = random.choices(range(24), weights=hour_weights)[0]
    
    interaction_datetime = interaction_date.replace(hour=hour, 
                                                    minute=random.randint(0, 59),
                                                    second=random.randint(0, 59))
    
    # Interaction type probabilities influenced by quality
    quality_factor = pin_quality
    interaction_probs = [
        0.60,  # impression
        0.20 * quality_factor,  # click
        0.10 * quality_factor,  # save
        0.08 * quality_factor,  # repin
        0.02  # close_up
    ]
    # Normalize probabilities
    interaction_probs = np.array(interaction_probs)
    interaction_probs = interaction_probs / interaction_probs.sum()
    
    interaction_type = np.random.choice(interaction_types, p=interaction_probs)
    
    # Session ID (some users have multiple interactions in same session)
    session_id = f"SESSION_{random.randint(1, NUM_INTERACTIONS // 3):08d}"
    
    # Device type
    device = random.choices(['Mobile', 'Desktop', 'Tablet'], 
                          weights=[0.70, 0.25, 0.05])[0]
    
    interactions_list.append({
        'interaction_id': f"INT_{len(interactions_list):08d}",
        'user_id': user_id,
        'pin_id': pin_id,
        'session_id': session_id,
        'interaction_type': interaction_type,
        'timestamp': interaction_datetime,
        'device': device
    })

interactions_df = pd.DataFrame(interactions_list)
interactions_df = interactions_df.sort_values('timestamp').reset_index(drop=True)

print(f"✓ Generated {len(interactions_df)} interactions")

# 4. Save Data
print("\nSaving datasets...")

users_df.to_csv('/home/claude/pinterest-engagement-analysis/data/raw/users.csv', index=False)
print("✓ Saved users.csv")

pins_df.to_csv('/home/claude/pinterest-engagement-analysis/data/raw/pins.csv', index=False)
print("✓ Saved pins.csv")

interactions_df.to_csv('/home/claude/pinterest-engagement-analysis/data/raw/interactions.csv', index=False)
print("✓ Saved interactions.csv")

# 5. Generate Summary Stats
print("\n" + "="*60)
print("DATA GENERATION COMPLETE")
print("="*60)
print(f"\nUsers: {len(users_df):,}")
print(f"Pins: {len(pins_df):,}")
print(f"Interactions: {len(interactions_df):,}")
print(f"\nDate Range: {START_DATE.date()} to {END_DATE.date()}")
print(f"\nTop Categories:")
print(pins_df['category'].value_counts().head())
print(f"\nInteraction Types:")
print(interactions_df['interaction_type'].value_counts())
print("\nFiles saved to /home/claude/pinterest-engagement-analysis/data/raw/")
