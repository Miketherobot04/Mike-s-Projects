-- Pinterest User Engagement Analysis - SQL Queries
-- Author: Michael Oyetibo
-- Date: January 2026

-- =============================================================================
-- 1. DATA EXPLORATION QUERIES
-- =============================================================================

-- Overview of platform metrics
SELECT 
    COUNT(DISTINCT user_id) as total_users,
    COUNT(DISTINCT pin_id) as total_pins,
    COUNT(*) as total_interactions,
    COUNT(*) * 1.0 / COUNT(DISTINCT user_id) as avg_interactions_per_user
FROM interactions;

-- Daily active users trend
SELECT 
    DATE(timestamp) as date,
    COUNT(DISTINCT user_id) as daily_active_users,
    COUNT(*) as daily_interactions
FROM interactions
GROUP BY DATE(timestamp)
ORDER BY date;

-- =============================================================================
-- 2. USER ENGAGEMENT METRICS
-- =============================================================================

-- Calculate user engagement scores
WITH user_metrics AS (
    SELECT 
        user_id,
        COUNT(*) as total_interactions,
        COUNT(DISTINCT pin_id) as unique_pins_interacted,
        COUNT(DISTINCT DATE(timestamp)) as active_days,
        SUM(CASE WHEN interaction_type = 'save' THEN 1 ELSE 0 END) as saves,
        SUM(CASE WHEN interaction_type = 'repin' THEN 1 ELSE 0 END) as repins,
        SUM(CASE WHEN interaction_type = 'click' THEN 1 ELSE 0 END) as clicks,
        SUM(CASE WHEN interaction_type = 'impression' THEN 1 ELSE 0 END) as impressions,
        MIN(timestamp) as first_interaction,
        MAX(timestamp) as last_interaction
    FROM interactions
    GROUP BY user_id
)
SELECT 
    user_id,
    total_interactions,
    unique_pins_interacted,
    active_days,
    ROUND(total_interactions * 1.0 / active_days, 2) as avg_interactions_per_day,
    saves + repins as high_value_actions,
    ROUND((saves + repins + clicks) * 100.0 / NULLIF(impressions, 0), 2) as engagement_rate_pct,
    JULIANDAY('now') - JULIANDAY(last_interaction) as days_since_last_interaction
FROM user_metrics
ORDER BY total_interactions DESC;

-- =============================================================================
-- 3. PIN PERFORMANCE ANALYSIS
-- =============================================================================

-- Top performing pins by engagement rate
WITH pin_engagement AS (
    SELECT 
        p.pin_id,
        p.category,
        p.content_type,
        p.has_description,
        p.has_link,
        COUNT(DISTINCT i.user_id) as unique_users,
        SUM(CASE WHEN i.interaction_type = 'impression' THEN 1 ELSE 0 END) as impressions,
        SUM(CASE WHEN i.interaction_type = 'click' THEN 1 ELSE 0 END) as clicks,
        SUM(CASE WHEN i.interaction_type = 'save' THEN 1 ELSE 0 END) as saves,
        SUM(CASE WHEN i.interaction_type = 'repin' THEN 1 ELSE 0 END) as repins,
        COUNT(*) as total_interactions
    FROM pins p
    LEFT JOIN interactions i ON p.pin_id = i.pin_id
    GROUP BY p.pin_id, p.category, p.content_type, p.has_description, p.has_link
)
SELECT 
    pin_id,
    category,
    content_type,
    has_description,
    has_link,
    unique_users,
    total_interactions,
    impressions,
    clicks,
    saves,
    repins,
    ROUND((saves + repins + clicks) * 100.0 / NULLIF(impressions, 0), 2) as engagement_rate_pct,
    ROUND(clicks * 100.0 / NULLIF(impressions, 0), 2) as click_through_rate_pct
FROM pin_engagement
WHERE impressions > 0
ORDER BY engagement_rate_pct DESC
LIMIT 50;

-- =============================================================================
-- 4. CATEGORY PERFORMANCE
-- =============================================================================

-- Performance metrics by category
SELECT 
    p.category,
    COUNT(DISTINCT p.pin_id) as total_pins,
    COUNT(DISTINCT i.user_id) as unique_users,
    COUNT(i.interaction_id) as total_interactions,
    ROUND(COUNT(i.interaction_id) * 1.0 / COUNT(DISTINCT p.pin_id), 2) as avg_interactions_per_pin,
    SUM(CASE WHEN i.interaction_type = 'save' THEN 1 ELSE 0 END) as total_saves,
    SUM(CASE WHEN i.interaction_type = 'repin' THEN 1 ELSE 0 END) as total_repins,
    SUM(CASE WHEN i.interaction_type = 'click' THEN 1 ELSE 0 END) as total_clicks,
    SUM(CASE WHEN i.interaction_type = 'impression' THEN 1 ELSE 0 END) as total_impressions,
    ROUND((SUM(CASE WHEN i.interaction_type IN ('save', 'repin', 'click') THEN 1 ELSE 0 END)) * 100.0 / 
          NULLIF(SUM(CASE WHEN i.interaction_type = 'impression' THEN 1 ELSE 0 END), 0), 2) as engagement_rate_pct
FROM pins p
LEFT JOIN interactions i ON p.pin_id = i.pin_id
GROUP BY p.category
ORDER BY engagement_rate_pct DESC;

-- =============================================================================
-- 5. CONTENT TYPE ANALYSIS
-- =============================================================================

-- Compare performance across content types
SELECT 
    p.content_type,
    COUNT(DISTINCT p.pin_id) as total_pins,
    ROUND(AVG(CASE WHEN i.interaction_type = 'save' THEN 1 ELSE 0 END), 4) as avg_saves_per_pin,
    ROUND(AVG(CASE WHEN i.interaction_type = 'repin' THEN 1 ELSE 0 END), 4) as avg_repins_per_pin,
    ROUND(AVG(CASE WHEN i.interaction_type = 'click' THEN 1 ELSE 0 END), 4) as avg_clicks_per_pin,
    COUNT(i.interaction_id) as total_interactions,
    ROUND(COUNT(i.interaction_id) * 1.0 / COUNT(DISTINCT p.pin_id), 2) as avg_interactions_per_pin
FROM pins p
LEFT JOIN interactions i ON p.pin_id = i.pin_id
GROUP BY p.content_type
ORDER BY avg_interactions_per_pin DESC;

-- =============================================================================
-- 6. TEMPORAL PATTERNS
-- =============================================================================

-- Hourly engagement patterns
SELECT 
    CAST(strftime('%H', timestamp) AS INTEGER) as hour_of_day,
    COUNT(*) as total_interactions,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT pin_id) as unique_pins,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) as pct_of_total
FROM interactions
GROUP BY hour_of_day
ORDER BY hour_of_day;

-- Day of week engagement patterns
SELECT 
    CASE CAST(strftime('%w', timestamp) AS INTEGER)
        WHEN 0 THEN 'Sunday'
        WHEN 1 THEN 'Monday'
        WHEN 2 THEN 'Tuesday'
        WHEN 3 THEN 'Wednesday'
        WHEN 4 THEN 'Thursday'
        WHEN 5 THEN 'Friday'
        WHEN 6 THEN 'Saturday'
    END as day_of_week,
    CAST(strftime('%w', timestamp) AS INTEGER) as day_num,
    COUNT(*) as total_interactions,
    COUNT(DISTINCT user_id) as unique_users,
    ROUND(AVG(CASE WHEN interaction_type = 'save' THEN 1 ELSE 0 END), 4) as save_rate
FROM interactions
GROUP BY day_of_week, day_num
ORDER BY day_num;

-- =============================================================================
-- 7. USER SEGMENTATION
-- =============================================================================

-- RFM-style user segmentation
WITH user_rfm AS (
    SELECT 
        i.user_id,
        u.user_type,
        u.age_group,
        u.country,
        JULIANDAY('now') - JULIANDAY(MAX(i.timestamp)) as recency_days,
        COUNT(*) as frequency,
        SUM(CASE WHEN i.interaction_type IN ('save', 'repin') THEN 1 ELSE 0 END) as monetary_value
    FROM interactions i
    JOIN users u ON i.user_id = u.user_id
    GROUP BY i.user_id, u.user_type, u.age_group, u.country
),
rfm_scores AS (
    SELECT 
        user_id,
        user_type,
        age_group,
        country,
        recency_days,
        frequency,
        monetary_value,
        NTILE(5) OVER (ORDER BY recency_days DESC) as R,
        NTILE(5) OVER (ORDER BY frequency) as F,
        NTILE(5) OVER (ORDER BY monetary_value) as M
    FROM user_rfm
)
SELECT 
    user_id,
    user_type,
    age_group,
    country,
    recency_days,
    frequency,
    monetary_value,
    R as recency_score,
    F as frequency_score,
    M as monetary_score,
    (R + F + M) / 3.0 as rfm_score,
    CASE 
        WHEN (R + F + M) / 3.0 >= 4 THEN 'Champions'
        WHEN (R + F + M) / 3.0 >= 3 THEN 'Loyal Users'
        WHEN (R + F + M) / 3.0 >= 2.5 THEN 'Potential Loyalists'
        WHEN R >= 3 AND (R + F + M) / 3.0 < 2.5 THEN 'Recent Users'
        WHEN F <= 2 AND M <= 2 THEN 'At Risk'
        ELSE 'Needs Attention'
    END as segment
FROM rfm_scores
ORDER BY rfm_score DESC;

-- =============================================================================
-- 8. COHORT ANALYSIS
-- =============================================================================

-- User retention by signup cohort
WITH user_cohorts AS (
    SELECT 
        user_id,
        DATE(signup_date, 'start of month') as cohort_month
    FROM users
),
user_activity AS (
    SELECT 
        i.user_id,
        DATE(i.timestamp, 'start of month') as activity_month
    FROM interactions i
)
SELECT 
    uc.cohort_month,
    ua.activity_month,
    COUNT(DISTINCT uc.user_id) as cohort_size,
    COUNT(DISTINCT ua.user_id) as active_users,
    ROUND(COUNT(DISTINCT ua.user_id) * 100.0 / COUNT(DISTINCT uc.user_id), 2) as retention_rate
FROM user_cohorts uc
LEFT JOIN user_activity ua ON uc.user_id = ua.user_id
GROUP BY uc.cohort_month, ua.activity_month
ORDER BY uc.cohort_month, ua.activity_month;

-- =============================================================================
-- 9. CREATOR PERFORMANCE
-- =============================================================================

-- Top creators by engagement
SELECT 
    p.creator_id,
    u.user_type,
    u.country,
    COUNT(DISTINCT p.pin_id) as pins_created,
    COUNT(DISTINCT i.user_id) as unique_viewers,
    COUNT(i.interaction_id) as total_interactions,
    SUM(CASE WHEN i.interaction_type = 'save' THEN 1 ELSE 0 END) as total_saves,
    SUM(CASE WHEN i.interaction_type = 'repin' THEN 1 ELSE 0 END) as total_repins,
    ROUND(COUNT(i.interaction_id) * 1.0 / COUNT(DISTINCT p.pin_id), 2) as avg_interactions_per_pin,
    ROUND(SUM(CASE WHEN i.interaction_type IN ('save', 'repin') THEN 1 ELSE 0 END) * 1.0 / 
          COUNT(DISTINCT p.pin_id), 2) as avg_high_value_actions_per_pin
FROM pins p
LEFT JOIN interactions i ON p.pin_id = i.pin_id
LEFT JOIN users u ON p.creator_id = u.user_id
GROUP BY p.creator_id, u.user_type, u.country
HAVING pins_created >= 5
ORDER BY avg_interactions_per_pin DESC
LIMIT 100;

-- =============================================================================
-- 10. DEVICE AND PLATFORM ANALYSIS
-- =============================================================================

-- Engagement by device type
SELECT 
    device,
    COUNT(*) as total_interactions,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT pin_id) as unique_pins,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) as pct_of_interactions,
    ROUND(AVG(CASE WHEN interaction_type = 'save' THEN 1 ELSE 0 END), 4) as save_rate,
    ROUND(AVG(CASE WHEN interaction_type = 'click' THEN 1 ELSE 0 END), 4) as click_rate
FROM interactions
GROUP BY device
ORDER BY total_interactions DESC;

-- =============================================================================
-- 11. VIRAL CONTENT IDENTIFICATION
-- =============================================================================

-- Identify potentially viral pins (high engagement in short time)
WITH pin_velocity AS (
    SELECT 
        p.pin_id,
        p.category,
        p.content_type,
        p.created_date,
        COUNT(DISTINCT i.user_id) as unique_users,
        COUNT(i.interaction_id) as total_interactions,
        JULIANDAY(MAX(i.timestamp)) - JULIANDAY(p.created_date) as days_since_creation,
        COUNT(i.interaction_id) * 1.0 / 
            NULLIF(JULIANDAY(MAX(i.timestamp)) - JULIANDAY(p.created_date), 0) as interactions_per_day
    FROM pins p
    LEFT JOIN interactions i ON p.pin_id = i.pin_id
    WHERE i.timestamp IS NOT NULL
    GROUP BY p.pin_id, p.category, p.content_type, p.created_date
    HAVING days_since_creation > 0
)
SELECT 
    pin_id,
    category,
    content_type,
    unique_users,
    total_interactions,
    days_since_creation,
    ROUND(interactions_per_day, 2) as interactions_per_day,
    CASE 
        WHEN interactions_per_day > 100 THEN 'Viral'
        WHEN interactions_per_day > 50 THEN 'Trending'
        WHEN interactions_per_day > 20 THEN 'Popular'
        ELSE 'Normal'
    END as virality_status
FROM pin_velocity
WHERE total_interactions >= 100
ORDER BY interactions_per_day DESC
LIMIT 50;

-- =============================================================================
-- 12. BUSINESS IMPACT QUERIES
-- =============================================================================

-- Overall platform health dashboard
SELECT 
    'Platform Metrics' as metric_category,
    COUNT(DISTINCT user_id) as value,
    'Total Users' as metric_name
FROM users
UNION ALL
SELECT 
    'Platform Metrics',
    COUNT(DISTINCT user_id),
    'Active Users (Last 30 Days)'
FROM interactions
WHERE DATE(timestamp) >= DATE('now', '-30 days')
UNION ALL
SELECT 
    'Engagement Metrics',
    COUNT(*),
    'Total Interactions'
FROM interactions
UNION ALL
SELECT 
    'Engagement Metrics',
    ROUND(AVG(daily_interactions), 2),
    'Avg Daily Interactions'
FROM (
    SELECT DATE(timestamp) as date, COUNT(*) as daily_interactions
    FROM interactions
    GROUP BY DATE(timestamp)
)
UNION ALL
SELECT 
    'Content Metrics',
    COUNT(*),
    'Total Pins'
FROM pins
UNION ALL
SELECT 
    'Content Metrics',
    COUNT(*),
    'Pins with Engagement'
FROM (
    SELECT DISTINCT pin_id FROM interactions
);
